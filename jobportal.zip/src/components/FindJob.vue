<template>
 <div class="slider-area ">
            <div class="single-slider section-overly slider-height2 d-flex align-items-center" style="background:url(/assets/img/hero/about.jpg)">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="hero-cap text-center">
                                <h2>Get your job</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</template>